<?php require('dbconnect.php'); ?>
<!doctype html>
<html lang="ja">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../../../css/style.css">

        <title>goods database</title>
    </head>
    <body>
        <header>
            <h1 class="font-weight-normal">トップページ</h1>
        </header>

        <main>
            <h2>商品データに行う処理を選択してください</h2>
            <article>
                <a href="register.php">登録</a>：商品データの新規登録<br>
                <a href="search.php">検索</a>：商品データの検索・確認<br>
                <a href="update_standby.php">変更</a>：商品データの更新・修正<br>
                <a href="delete.php">削除</a>：商品データの削除<br>
            </article>
        </main>
    </body>
</html>
